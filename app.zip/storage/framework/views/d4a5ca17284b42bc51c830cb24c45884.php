<table>
    <thead>
        <tr>
            <th>Tanggal</th>
            <th>Outlet</th>
            <th>Jenis Promo</th>
            <th>Deskripsi</th>
            <th>Pengunjung</th>
            <th>Status</th>
            <th>Admin Note</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($p->promo_date); ?></td>
            <td><?php echo e($p->outlet->name ?? '-'); ?></td>
            <td><?php echo e($p->promo_type); ?></td>
            <td><?php echo e($p->description); ?></td>
            <td><?php echo e($p->estimated_traffic); ?></td>
            <td><?php echo e($p->status); ?></td>
            <td><?php echo e($p->admin_note); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\projectweb\localhost\tes-mykopi4\resources\views/exports/promotions.blade.php ENDPATH**/ ?>